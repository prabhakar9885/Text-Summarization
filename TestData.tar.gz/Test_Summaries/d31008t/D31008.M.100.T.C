A passerby who found Matthew Shepard's nearly lifeless body tied to a fence outside Laramie, Wyoming at first thought it was a scarecrow.
Matthew, an openly gay student at the University of Wyoming, had been kidnapped, brutally beaten and left to die in near freezing temperatures.
Two men, Russell Henderson and Aaron McKinney were arrested on charges of kidnapping and attempted first degree murder.
Two women, friends of the accused, were charged as accessories after the fact.
Seeing this as a hate crime, gay-rights activists nationwide renewed efforts to get the Clinton Administration to pass hate-crime legislation.
