Although China was expected to sign a key U.N. human rights treaty, it continues to question and arrest political dissidents.
Qin Yongmin was arrested following his attempt to form a human rights monitoring group.
Fellow dissident Xu Wenli was arrested for trying to form an opposition party.
Another dissident flew China for the U.S. to avoid arrest.
In making the arrests, China has charged that the dissidents have threatened national security.
Facing trial, Xu Wenli and Qin Yongmin were unable to obtain legal counsel.
Qin Youngmin, attempting to defend himself, was cut off several times by the judge in a trial lasting just over two hours.
