Gale-force winds and high seas struck the 155 participants in Australia's Sydney to Hobart yacht race.
One sailor, Glyn Charles, who was swept off the yacht Sword of Orion, is presumed drowned and two seamen on the Business Post Naiad were killed.
Search and rescue efforts were stretched to the limit also as three yachts turned up missing.
One yacht, the B-52 was found with the crew safe.
Race organizers never considered canceling the race, claiming that the skippers controlled whether to stay in the race or drop out.
A total of 37 yachts were forced out of the race, many of which had lost their masts.
