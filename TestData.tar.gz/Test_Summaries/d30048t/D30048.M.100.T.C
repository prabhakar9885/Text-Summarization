As Latin American nations gathered for the Ibero-American summit, there was general concern for the global economy.
Most leaders attending warned that the downturn in the global economy could have dire consequences.
The crisis facing Latin America has had an effect on the U.S. economy as exports declined as a result of the recession.
Brazil's economy was especially hard hit and it has entered into talks with the IMF to secure loans needed to bolster its economy.
The outcome of these talks could depend on the outcome of the Brazilian elections.
In an effort to cuts its deficit, Brazil has cut back on the perks of government workers.
