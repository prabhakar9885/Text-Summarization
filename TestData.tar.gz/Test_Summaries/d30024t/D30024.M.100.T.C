Speaker of the House Newt Gingrich has announced that he will not seek re-election to the post when the vote comes up on November 18th.
He also announced that he would be leaving the House when his current term as Speaker expires in January.
This announcement comes on the heels of a poor Republican showing in the mid-term elections.
Although the Republicans retained a majority in the House, the Margin of Republican control shrank in the face of Democratic gains.
Gingrich had been seen as the man who led the Republicans our of the doldrums into control of the House and the Senate.
