Tensions between Syria and Turkey increased as Turkey sent 10,000 troops to its border with Syria.
The dispute comes amid accusations by Turkey that Syria helping Kurdish rebels based in Syria.
Kurdish rebels have been conducting cross border raids into Turkey in an effort to gain Kurdish autonomy in the region.
Egyptian President Mubarek has been involved in shuttle diplomacy to the two states in an effort to defuse the situation and Iraq also has offered to mediate the dispute between the two countries.
Although Israel has tried to demonstrate its neutrality, Lebanon has charged That Israel is the cause of the tensions between Syria and Turkey.
