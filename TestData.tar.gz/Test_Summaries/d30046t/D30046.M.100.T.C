As impeachment proceedings in the House approached a climax, House members were stunned by an admission from House Speaker elect Livingston that he was guilty of an adulterous affair.
The admission follows disclosures by Hustler published Larry Flynn, who had offered one million dollars to anyone who could provide such information on a House or Senate member.
Livingston's admission was met with a standing ovation by House members, as was his subsequent resignation.
In resigning, Livingston called on President Clinton to do the same.
Political pundits see the whole process as driven by partisan politics.
